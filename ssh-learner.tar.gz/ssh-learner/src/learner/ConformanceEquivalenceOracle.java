//package learner;
//
//import java.io.BufferedReader;
//import java.io.File;
//import java.io.IOException;
//import java.io.InputStreamReader;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Iterator;
//import java.util.List;
//
//import de.ls5.jlearn.interfaces.Automaton;
//import de.ls5.jlearn.util.DotUtil;
//import main.DotToNuSMVTransformer;
//import main.SpecReader;
//import util.Dot;
//
//public class ConformanceEquivalenceOracle extends  AbstractEquivalenceOracle{
//	// temporary hyp files
//	private static final String TEMP_HYP_DOT = "tempHyp.dot";
//	private static final String TEMP_HYP_NUSMV = "tempHyp.smv";
//	// in and out variables in spec used by SpecReader
//	private static final String INPUT_VAR = "inp";
//	private static final String OUTPUT_VAR = "out";
//
//	private ProcessBuilder pb;
//	private DotToNuSMVTransformer transformer;
//	private List<List<String>> testSuite;
//	private Iterator<List<String>> testIterator;
//
//	public ConformanceEquivalenceOracle(String nuSMVCommand, String specFile) throws IOException{
//		// the comand will be NuSMV ... TEMP_HYP_NUSMV
//		String[] nuSMVCmd = nuSMVCommand.split("//s");
//		String[] prCmd = Arrays.copyOf(nuSMVCmd, nuSMVCmd.length + 1);
//		prCmd[nuSMVCmd.length] = TEMP_HYP_NUSMV;
//		this.pb = new ProcessBuilder(prCmd);
//		this.transformer = new DotToNuSMVTransformer();
//		this.transformer.addSpecFile(specFile, INPUT_VAR, OUTPUT_VAR);
//	}
//
//	public void initialize(Automaton hyp) {
//		DotUtil.writeDot(hyp,  new File(TEMP_HYP_DOT));
//		try {
//			transformer.generateNuSMVModel(TEMP_HYP_DOT, TEMP_HYP_NUSMV);
//			testSuite = runNuSMV();
//			testIterator = testSuite.iterator();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//
//		}
//	}
//
//	  /**
//     * Starts the process and creates buffered/whatnot streams for stdin stderr
//     * or the external program
//     *
//     */
//    private List<List<String>> runNuSMV() throws IOException {
//        Process process = pb.start();
//    	BufferedReader  processOutput = new BufferedReader(new InputStreamReader(
//                process.getInputStream()));
//        List<List<String>> tests = new ArrayList<>();
//        String line;
//        while((line = processOutput.readLine()) != null) {
//        	if (line.contains("Counterexample")) {
//        		System.out.println("Extracting test");
//        		List<String> test = extractTest(processOutput);
//        		tests.add(test);
//        	}
//        }
//        processOutput.close();
//        process.destroy();
//        return tests;
//    }
//
//	private List<String> extractTest(BufferedReader processOutput) throws IOException {
//		String line;
//		String input = null;
//		List<String> test = new ArrayList<String>();
//        while((line = processOutput.readLine()) != null && !line.contains("specification")) {
//        	if (line.contains("State:") && input != null)
//        		test.add(input);
//        	else {
//        		if (line.contains(INPUT_VAR)) {
//        			input = SpecReader.getVarValuations(INPUT_VAR, line).get(0);
//        		}
//        	}
//        }
//		return test;
//	}
//
//	protected List<String> nextTest() {
//		if (testIterator.hasNext())
//			return testIterator.next();
//		else
//			return null;
//	}
//
//	protected void close() {
//	//	new File(TEMP_HYP_NUSMV).delete();
//	//	new File(TEMP_HYP_DOT).delete();
//	}
//
//	// NuSMV command, .smv spec, .dot hyp
//	public static void main(String args []) throws Exception{
//		if (args.length < 2) {
//			System.out.println("USEAGE: java main NuSMV_command, .smv_spec, .dot_hyp");
//			System.exit(0);
//		}
//		ConformanceEquivalenceOracle eqOracle = new ConformanceEquivalenceOracle(args[0], args[1]);
//		Automaton hyp = Dot.readFile(args[2]);
//		eqOracle.initialize(hyp);
//		System.out.println("Generated tests:");
//		List<String> test;
//		while ((test=eqOracle.nextTest()) != null)
//			System.out.println(test);
//		eqOracle.close();
//	}
//}
