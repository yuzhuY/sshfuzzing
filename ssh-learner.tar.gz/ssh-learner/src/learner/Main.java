package learner;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

import de.ls5.jlearn.algorithms.packs.ObservationPack;
import de.ls5.jlearn.interfaces.Automaton;
import de.ls5.jlearn.interfaces.EquivalenceOracle;
import de.ls5.jlearn.interfaces.EquivalenceOracleOutput;
import de.ls5.jlearn.interfaces.Learner;
import de.ls5.jlearn.interfaces.Word;
import de.ls5.jlearn.logging.LearnLog;
import de.ls5.jlearn.logging.LogLevel;
import de.ls5.jlearn.logging.PrintStreamLoggingAppender;
import de.ls5.jlearn.shared.AlphabetImpl;
import de.ls5.jlearn.shared.AutomatonImpl;
import de.ls5.jlearn.util.DotUtil;
import util.FileManager;
import util.SoundUtils;

public class Main {
	private static final int maxNumTraces = 10000;
	private static final long timestamp = System.currentTimeMillis();

	// output file(name)s
	private static final String outDir = "output/";
	private static final String outputFile = outDir + "out.txt";
	private static final String statisticsFile = outDir + "statistics.txt";
	private static final String learnedModelFile = outDir + "learnresult.dot";
	public static final String dbFile = outDir + "querylog.db";

	private static final String hypFile(int hypNum) {
		return outDir + "hypothesis-" + hypNum + ".dot";
	}

	private static final String learnLog = outDir + "learnLog.txt";

	// input file(name)s
	private static final String emptyDbFile = "input/querylog-empty.db";
	private static final String configFile = "input/config.prop";
	private static final String oldStatsFile = "input/statistics.txt"; // used
																		// to
																		// extract
																		// test
																		// words
																		// so as
																		// to
																		// recreate
																		// previous
																		// learning
																		// runs

	// yannakakis commands
	private static final String yannakakisExhaustiveCmd = "yanna/main --seed 70 = fixed 2 4"; // exhaustive
																								// yannakakis
																								// search
																								// with
																								// k
																								// =
																								// 2
	private static final String yannakakisRandomCmd = "yanna/main --prefix buggy --seed 123456789 = random 4 4"; // random
																													// yannakakis
																													// search
																													// with
																													// random
																													// length
																													// 4

	// global hyp counter
	private static int hypCounter = 0;

	private static enum EquType {
		RANDOM, EXHAUSTIVE, WORDS, CONFORMANCE
	}

	private PrintStream statisticsFileStream;

	public static void main(String[] args) {
		Main main = new Main();
		try {
			final Config config = new Config(Main.configFile);
			// we set up a shutdown hook that will copy all files to an
			// experiments folder
			Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
				public void run() {
					try {
						copyToExpFolder(config.sutName, timestamp);
						
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}));

			Automaton learnedModel = main.learn(config);
			SoundUtils.success();
			File modelFile = new File(learnedModelFile);//dot file
			// Write final dot
			DotUtil.writeDot(learnedModel, modelFile);

			// Open dot file
			Desktop.getDesktop().open(modelFile);
		} catch (Exception e) {
			e.printStackTrace();
			SoundUtils.failure();
		}
	}

	public static void copyToExpFolder(String sutName, long timestamp) throws Exception {
		String expFolder = outDir + sutName + timestamp + "/";
		String[] hypFiles = new String[hypCounter + 1];
		for (int i = 0; i <= hypCounter; i++) {
			hypFiles[i] = hypFile(i);
		}

		// the files to carry to the exp folder
		copyToExpFolder(expFolder, hypFiles);
		for (String hypFile : hypFiles) {
			new File(hypFile).delete(); // we delete hyp files
		}
		copyToExpFolder(expFolder, outputFile);
		copyToExpFolder(expFolder, statisticsFile);
		copyToExpFolder(expFolder, dbFile);
		copyToExpFolder(expFolder, configFile);
		copyToExpFolder(expFolder, learnedModelFile);
		copyToExpFolder(expFolder, learnLog);
	}

	private static class Config {
		/*
		 * Example: equOracle="RANDOM;EXHAUSTIVE" maxNumTests=2000
		 */
		public final List<EquType> equOracleTypes;
		// applies only to equ oracles which otherwise would be unbounded.
		public final Integer maxNumTests;
		public final List<String> alphabet;
		public final List<String> testWords;
		public String specFile;
		public final String sutName;
		private String nusmvCmd;

		public Config(String file) throws IOException {
			Properties propFile = new Properties();
			if (!new File(file).exists())
				System.out.println("The property file " + propFile + " doesn't exist. Loading default configurations.");
			propFile.load(new FileInputStream(file));
			this.sutName = (String) propFile.getOrDefault("name", "aSut");
			String equOraclesString = (String) propFile.getOrDefault("eqOracle", "RANDOM");
			equOracleTypes = new ArrayList<EquType>();
			for (String equOracleStr : equOraclesString.split(";")) {
				EquType equOracle = EquType.valueOf(equOracleStr.trim().toUpperCase());
				if (equOracle == null)
					throw new RuntimeException(
							"Invalid equ oracle" + equOracleStr + ". Select from " + Arrays.toString(EquType.values()));
				equOracleTypes.add(equOracle);
			}
			String[] inputs = propFile.get("alphabet").toString().split(";");
			alphabet = Arrays.stream(inputs).map(str -> str.toUpperCase()).filter(str -> !str.startsWith("!")) // !
																												// is
																												// used
																												// for
																												// commented
																												// inputs
					.collect(Collectors.<String>toList());

			// efficient computing... not
			maxNumTests = Integer.valueOf((String) propFile.getOrDefault("maxNumTests", String.valueOf(maxNumTraces)));
			testWords = new ArrayList<>();
			if (equOracleTypes.contains(EquType.WORDS)) {
				// getting test words from old stats file
				if (new File(oldStatsFile).exists()) {
					BufferedReader reader = new BufferedReader(new FileReader(oldStatsFile));
					String str;
					while ((str = reader.readLine()) != null)
						if (str.startsWith("Counter Example:"))
							testWords.add(str.replace("Counter Example:", "").trim());
				}

			}
			if (equOracleTypes.contains(EquType.CONFORMANCE)) {
				String specFileName = requireGet(EquType.CONFORMANCE, "specification", propFile);
				specFile = "input/" + specFileName;
				nusmvCmd = requireGet(EquType.CONFORMANCE, "nusmvCmd", propFile);
			}
		}

		public String toString() {
			return "Equ Oracles: " + this.equOracleTypes + "; MaxNumTests: " + maxNumTests;
		}

		private String requireGet(EquType type, String param, Properties propFile) {
			String paramVal = (String) propFile.getProperty(param);
			if (paramVal == null)
				throw new RuntimeException("Parameter " + param + " must be specified for Equ Oracle " + type);
			return paramVal;
		}
	}

	public Main() {

	}

	public Automaton learn(Config config) throws Exception {
		if (!new File(outDir).exists()) {
			new File(outDir).mkdirs();
		}


		// All output goes to file
		statisticsFileStream = new PrintStream(new FileOutputStream(statisticsFile, false));

		PrintStream fileStream = new PrintStream(new FileOutputStream(outputFile, false));

		System.setOut(fileStream);//export all out files to out.txt file, so you can see hahahahaxxxx at that file

		statisticsFileStream.println(yannakakisRandomCmd); // Check if eclipse
															// is not being dumb
															// and is running
															// old commands
		statisticsFileStream.println(yannakakisExhaustiveCmd);

		// Set up a connection
		Socket sock = new Socket("localhost", 8000);
		System.out.println("Created a shared socket on local port " + sock.getLocalPort());

		// Disable Nagle's delay algorithm
		sock.setTcpNoDelay(true);

		// Logging info goes to System.out
		LearnLog.addAppender(
				new PrintStreamLoggingAppender(LogLevel.DEBUG, new PrintStream(new FileOutputStream(learnLog, false))));

		// Some debug info
		System.out.println("Started the main process");
		System.out.println("Maximum number of traces: " + maxNumTraces);
		System.out.println("Timestamp: " + timestamp);
		System.out.println("Configuration: " + config);

		// if cache not present, make a copy of an empty db
		if (!new File(dbFile).exists()) {
			Path emptyDbPath = Paths.get(emptyDbFile);
			Files.copy(emptyDbPath, new FileOutputStream(dbFile));
		}

		// Set up database
		Logger sqllog = new Logger(dbFile, config.sutName);

		// And mapper
		Mapper mapper = new Mapper(sock, sqllog);

		// Create learnlib objects: membershipOracle, EquivalenceOracles and
		// Learner
		MembershipOracle memberOracle = new MembershipOracle(sock, sqllog);
		mapper.setMembershipOracle(memberOracle);

		// Set up the eqOracleMap (equType -> equOracle)
		EnumMap<EquType, EquivalenceOracle> equOracleMap = new EnumMap<EquType, EquivalenceOracle>(EquType.class);
		for (EquType equType : config.equOracleTypes) {
			EquivalenceOracle eqOracle = null;
			switch (equType) {
			case RANDOM:
				eqOracle = new YannakakisEquivalenceOracle(yannakakisRandomCmd, config.maxNumTests);
				break;
			case EXHAUSTIVE:
				eqOracle = new YannakakisEquivalenceOracle(yannakakisExhaustiveCmd);
				break;
			case WORDS:
				eqOracle = new WordsEquivalenceOracle(config.testWords);
				break;
//			case CONFORMANCE:
//				eqOracle = new ConformanceEquivalenceOracle(config.nusmvCmd, config.specFile);
//				break;
			}
			eqOracle.setOracle(mapper);
			equOracleMap.put(equType, eqOracle);
		}

		Learner learner = null;

		// Set up the learner
		learner = new ObservationPack();
		learner.setOracle(memberOracle);
		learner.setAlphabet(mapper.generateInputAlphabet(config.alphabet));

		long start = System.currentTimeMillis();
		boolean done = false;
		int memQueries = 0, testQueries = 0;

		// Repeat until a hypothesis has been formed for which no counter
		// example can be found
		for (hypCounter = 0; !done; hypCounter++) {
			Automaton hyp = null;

			// Learn
			System.out.println("starting learning");
			learner.learn();
			System.out.println("done learning");

			// Print some stats
			statisticsFileStream
					.println("Hypothesis " + hypCounter + " after: " + (System.currentTimeMillis() - start) + "ms");
			statisticsFileStream.println("Membership: " + (memberOracle.getNumQueries() - memQueries));
			memQueries = memberOracle.getNumQueries();
			// memberOracle.resetNumQueries();

			// Retrieve hypothesis and write to dot file
			hyp = learner.getResult();
			DotUtil.writeDot(hyp, new File(hypFile(hypCounter)));

			EquivalenceOracleOutput equivOutput = null;

			for (EquType equOracleType : config.equOracleTypes) {
				EquivalenceOracle eqOracle = equOracleMap.get(equOracleType);
				System.out.println("starting " + equOracleType.name() + " equivalence query");
				// mapper.setRetrieveFromCache(false);
				equivOutput = eqOracle.findCounterExample(hyp);
				if (equivOutput != null)
					break;
				// mapper.setRetrieveFromCache(true);
				System.out.println("done " + equOracleType.name() + " equivalence query");

				statisticsFileStream
						.println(equOracleType.name() + " Equivalence: " + (mapper.getNumQueries() - testQueries));
				testQueries = mapper.getNumQueries();
				// mapper.resetNumQueries();
			}

			// Check for a counterexample
			if (equivOutput == null) {
				// No counterexample: close socket and done.
				System.out.println("No counterexample found; done!");
				sock.close();
				done = true;
			} else {
				// There is a counter example, send it to learnlib.
				Word counterExample = equivOutput.getCounterExample();

				statisticsFileStream.println("Counter Example: " + counterExample.toString());
				System.out.println("Sending Counter Example to LearnLib.");
				System.out.println("Counter Example: " + counterExample.toString());
				learner.addCounterExample(counterExample, equivOutput.getOracleOutput());
			}
		}

		// End of learning, update some stats
		long end = System.currentTimeMillis();
		statisticsFileStream.println("Total mem Queries: " + memQueries);
		statisticsFileStream.println("Total test Queries: " + testQueries);
		statisticsFileStream.println("Timestamp: " + timestamp + ".");
		statisticsFileStream.println("Running time: " + (end - start) + "ms.");
		statisticsFileStream.close();

		// Get result
		Automaton learnedModel = learner.getResult();

		return learnedModel;
	}

	public static void copyToExpFolder(String expFolder, String... files) throws Exception {
		for (String file : files) {
			FileManager.copyFromTo(file, expFolder + new File(file).getName());
		}

	}

	public Automaton readExistingHypothesis(String filename) {
		System.out.println("Old hypothesis found");

		// TODO Read the dot-file associated with the filename, and construct
		// the corresponding Automaton.

		return new AutomatonImpl(new AlphabetImpl());
	}
}
